package com.example.myapplication.model;

public class User {
    public String fullname,emailid,mobileno;
    public User(){

    }
    public User(String fullname,String emailid,String mobileno){
        this.fullname = fullname;
        this.emailid = emailid;
        this.mobileno = mobileno;
    }
}
