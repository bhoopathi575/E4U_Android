package com.example.myapplication;

import androidx.appcompat.app.AppCompatActivity;

import android.content.Intent;
import android.graphics.Color;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.ImageView;

public class Bookseats extends AppCompatActivity implements View.OnClickListener {
    public Button button;
    public ImageView imageView1, imageView2,imageView3,imageView4,imageView5,imageView6,imageView7,imageView8,imageView9,imageView10,
            imageView11, imageView12,imageView13,imageView14,imageView15,imageView16,imageView17,imageView18,imageView19,imageView20,
            imageView21, imageView22,imageView23,imageView24,imageView25,imageView26,imageView27,imageView28,imageView29,imageView30,
            imageView31, imageView32,imageView33,imageView34,imageView35,imageView36,imageView37,imageView38,imageView39,imageView40,
            imageView41, imageView42,imageView43,imageView44,imageView45,imageView46,imageView47,imageView48,imageView49,imageView50,
            imageView51, imageView52,imageView53,imageView54,imageView55,imageView56,imageView57,imageView58,imageView59,imageView60,
            imageView61, imageView62,imageView63,imageView64,imageView65,imageView66,imageView67,imageView68,imageView69,imageView70;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_bookseats);
        getSupportActionBar().setDisplayHomeAsUpEnabled(true);


        imageView1 = (ImageView) findViewById(R.id.s2);
        imageView1.setOnClickListener(this);
        imageView2 = (ImageView) findViewById(R.id.s3);
        imageView2.setOnClickListener(this);
        imageView3 = (ImageView) findViewById(R.id.s4);
        imageView3.setOnClickListener(this);
        imageView4 = (ImageView) findViewById(R.id.s5);
        imageView4.setOnClickListener(this);
        imageView5 = (ImageView) findViewById(R.id.s6);
        imageView5.setOnClickListener(this);
        imageView6 = (ImageView) findViewById(R.id.s7);
        imageView6.setOnClickListener(this);
        imageView7 = (ImageView) findViewById(R.id.s8);
        imageView7.setOnClickListener(this);
        imageView8 = (ImageView) findViewById(R.id.s9);
        imageView8.setOnClickListener(this);
        imageView9 = (ImageView) findViewById(R.id.s10);
        imageView9.setOnClickListener(this);
        imageView10 = (ImageView) findViewById(R.id.s1);
        imageView10.setOnClickListener(this);
        imageView11 = (ImageView) findViewById(R.id.s11);
        imageView11.setOnClickListener(this);
        imageView12 = (ImageView) findViewById(R.id.s12);
        imageView12.setOnClickListener(this);
        imageView13 = (ImageView) findViewById(R.id.s13);
        imageView13.setOnClickListener(this);
        imageView14 = (ImageView) findViewById(R.id.s14);
        imageView14.setOnClickListener(this);
        imageView15 = (ImageView) findViewById(R.id.s15);
        imageView15.setOnClickListener(this);
        imageView16 = (ImageView) findViewById(R.id.s16);
        imageView16.setOnClickListener(this);
        imageView17 = (ImageView) findViewById(R.id.s17);
        imageView17.setOnClickListener(this);
        imageView18 = (ImageView) findViewById(R.id.s18);
        imageView18.setOnClickListener(this);
        imageView19 = (ImageView) findViewById(R.id.s19);
        imageView19.setOnClickListener(this);
        imageView20 = (ImageView) findViewById(R.id.s20);
        imageView20.setOnClickListener(this);
        imageView21 = (ImageView) findViewById(R.id.s21);
        imageView21.setOnClickListener(this);
        imageView22 = (ImageView) findViewById(R.id.s22);
        imageView22.setOnClickListener(this);
        imageView23 = (ImageView) findViewById(R.id.s23);
        imageView23.setOnClickListener(this);
        imageView24 = (ImageView) findViewById(R.id.s24);
        imageView24.setOnClickListener(this);
        imageView25 = (ImageView) findViewById(R.id.s25);
        imageView25.setOnClickListener(this);
        imageView26 = (ImageView) findViewById(R.id.s26);
        imageView26.setOnClickListener(this);
        imageView27 = (ImageView) findViewById(R.id.s27);
        imageView27.setOnClickListener(this);
        imageView28 = (ImageView) findViewById(R.id.s28);
        imageView28.setOnClickListener(this);
        imageView29 = (ImageView) findViewById(R.id.s29);
        imageView29.setOnClickListener(this);
        imageView30 = (ImageView) findViewById(R.id.s30);
        imageView30.setOnClickListener(this);
        imageView31 = (ImageView) findViewById(R.id.s31);
        imageView31.setOnClickListener(this);
        imageView32 = (ImageView) findViewById(R.id.s32);
        imageView32.setOnClickListener(this);
        imageView33 = (ImageView) findViewById(R.id.s33);
        imageView33.setOnClickListener(this);
        imageView34 = (ImageView) findViewById(R.id.s34);
        imageView34.setOnClickListener(this);
        imageView35 = (ImageView) findViewById(R.id.s35);
        imageView35.setOnClickListener(this);
        imageView36 = (ImageView) findViewById(R.id.s36);
        imageView36.setOnClickListener(this);
        imageView37 = (ImageView) findViewById(R.id.s37);
        imageView37.setOnClickListener(this);
        imageView38 = (ImageView) findViewById(R.id.s38);
        imageView38.setOnClickListener(this);
        imageView39 = (ImageView) findViewById(R.id.s39);
        imageView39.setOnClickListener(this);
        imageView40 = (ImageView) findViewById(R.id.s40);
        imageView40.setOnClickListener(this);
        imageView41 = (ImageView) findViewById(R.id.s41);
        imageView41.setOnClickListener(this);
        imageView42 = (ImageView) findViewById(R.id.s42);
        imageView42.setOnClickListener(this);
        imageView43 = (ImageView) findViewById(R.id.s43);
        imageView43.setOnClickListener(this);
        imageView44 = (ImageView) findViewById(R.id.s44);
        imageView44.setOnClickListener(this);
        imageView45 = (ImageView) findViewById(R.id.s45);
        imageView45.setOnClickListener(this);
        imageView46 = (ImageView) findViewById(R.id.s46);
        imageView46.setOnClickListener(this);
        imageView47 = (ImageView) findViewById(R.id.s47);
        imageView47.setOnClickListener(this);
        imageView48 = (ImageView) findViewById(R.id.s48);
        imageView48.setOnClickListener(this);
        imageView49 = (ImageView) findViewById(R.id.s49);
        imageView49.setOnClickListener(this);
        imageView50 = (ImageView) findViewById(R.id.s50);
        imageView50.setOnClickListener(this);
        imageView51 = (ImageView) findViewById(R.id.s51);
        imageView51.setOnClickListener(this);
        imageView52 = (ImageView) findViewById(R.id.s52);
        imageView52.setOnClickListener(this);
        imageView53 = (ImageView) findViewById(R.id.s53);
        imageView53.setOnClickListener(this);
        imageView54 = (ImageView) findViewById(R.id.s54);
        imageView54.setOnClickListener(this);
        imageView55 = (ImageView) findViewById(R.id.s55);
        imageView55.setOnClickListener(this);
        imageView56 = (ImageView) findViewById(R.id.s56);
        imageView56.setOnClickListener(this);
        imageView57 = (ImageView) findViewById(R.id.s57);
        imageView57.setOnClickListener(this);
        imageView58 = (ImageView) findViewById(R.id.s58);
        imageView58.setOnClickListener(this);
        imageView59 = (ImageView) findViewById(R.id.s59);
        imageView59.setOnClickListener(this);
        imageView60 = (ImageView) findViewById(R.id.s60);
        imageView60.setOnClickListener(this);

        imageView61 = (ImageView) findViewById(R.id.s61);
        imageView61.setOnClickListener(this);
        imageView62 = (ImageView) findViewById(R.id.s62);
        imageView62.setOnClickListener(this);
        imageView63 = (ImageView) findViewById(R.id.s63);
        imageView63.setOnClickListener(this);
        imageView64 = (ImageView) findViewById(R.id.s64);
        imageView64.setOnClickListener(this);
        imageView65 = (ImageView) findViewById(R.id.s65);
        imageView65.setOnClickListener(this);
        imageView66 = (ImageView) findViewById(R.id.s66);
        imageView66.setOnClickListener(this);
        imageView67 = (ImageView) findViewById(R.id.s67);
        imageView67.setOnClickListener(this);
        imageView68 = (ImageView) findViewById(R.id.s68);
        imageView68.setOnClickListener(this);
        imageView69 = (ImageView) findViewById(R.id.s69);
        imageView69.setOnClickListener(this);
        imageView70 = (ImageView) findViewById(R.id.s70);
        imageView70.setOnClickListener(this);







        button = (Button) findViewById(R.id.continuebtn);
        button.setOnClickListener(this);


    }

    public void onClick(View v) {
        switch (v.getId()) {
            case R.id.continuebtn:
                startActivity(new Intent(Bookseats.this, PaymentPage.class));
                break;
            case R.id.s1:
                imageView10.setSelected(!imageView10.isSelected());
                if (imageView10.isSelected()) {
                    imageView10.setColorFilter(getResources().getColor(R.color.black));
                } else {
                    imageView10.setColorFilter(getResources().getColor(R.color.white));

                }
                break;
            case R.id.s2:
                imageView1.setSelected(!imageView1.isSelected());
                if (imageView1.isSelected()) {
                    imageView1.setColorFilter(getResources().getColor(R.color.black));
                } else {
                    imageView1.setColorFilter(getResources().getColor(R.color.white));

                }
                break;
            case R.id.s3:
                imageView2.setSelected(!imageView2.isSelected());
                if (imageView2.isSelected()) {
                    imageView2.setColorFilter(getResources().getColor(R.color.black));
                } else {
                    imageView2.setColorFilter(getResources().getColor(R.color.white));

                }
                break;
            case R.id.s4:
                imageView3.setSelected(!imageView3.isSelected());
                if (imageView3.isSelected()) {
                    imageView3.setColorFilter(getResources().getColor(R.color.black));
                } else {
                    imageView3.setColorFilter(getResources().getColor(R.color.white));

                }
                break;
            case R.id.s5:
                imageView4.setSelected(!imageView4.isSelected());
                if (imageView4.isSelected()) {
                    imageView4.setColorFilter(getResources().getColor(R.color.black));
                } else {
                    imageView4.setColorFilter(getResources().getColor(R.color.white));

                }
                break;
            case R.id.s6:
                imageView5.setSelected(!imageView5.isSelected());
                if (imageView5.isSelected()) {
                    imageView5.setColorFilter(getResources().getColor(R.color.black));
                } else {
                    imageView5.setColorFilter(getResources().getColor(R.color.white));

                }
                break;
            case R.id.s7:
                imageView6.setSelected(!imageView6.isSelected());
                if (imageView6.isSelected()) {
                    imageView6.setColorFilter(getResources().getColor(R.color.black));
                } else {
                    imageView6.setColorFilter(getResources().getColor(R.color.white));

                }
                break;
            case R.id.s8:
                imageView7.setSelected(!imageView7.isSelected());
                if (imageView7.isSelected()) {
                    imageView7.setColorFilter(getResources().getColor(R.color.black));
                } else {
                    imageView7.setColorFilter(getResources().getColor(R.color.white));

                }
                break;
            case R.id.s9:
                imageView8.setSelected(!imageView8.isSelected());
                if (imageView8.isSelected()) {
                    imageView8.setColorFilter(getResources().getColor(R.color.black));
                } else {
                    imageView8.setColorFilter(getResources().getColor(R.color.white));

                }

                break;
            case R.id.s10:
                imageView9.setSelected(!imageView9.isSelected());
                if (imageView9.isSelected()) {
                    imageView9.setColorFilter(getResources().getColor(R.color.black));
                } else {
                    imageView9.setColorFilter(getResources().getColor(R.color.white));

                }

                break;

            case R.id.s11:
                imageView11.setSelected(!imageView11.isSelected());
                if (imageView11.isSelected()) {
                    imageView11.setColorFilter(getResources().getColor(R.color.black));
                } else {
                    imageView11.setColorFilter(getResources().getColor(R.color.white));

                }
                break;
            case R.id.s12:
                imageView12.setSelected(!imageView12.isSelected());
                if (imageView12.isSelected()) {
                    imageView12.setColorFilter(getResources().getColor(R.color.black));
                } else {
                    imageView12.setColorFilter(getResources().getColor(R.color.white));

                }
                break;
            case R.id.s13:
                imageView13.setSelected(!imageView13.isSelected());
                if (imageView13.isSelected()) {
                    imageView13.setColorFilter(getResources().getColor(R.color.black));
                } else {
                    imageView13.setColorFilter(getResources().getColor(R.color.white));

                }
                break;
            case R.id.s14:
                imageView14.setSelected(!imageView14.isSelected());
                if (imageView14.isSelected()) {
                    imageView14.setColorFilter(getResources().getColor(R.color.black));
                } else {
                    imageView14.setColorFilter(getResources().getColor(R.color.white));

                }
                break;
            case R.id.s15:
                imageView15.setSelected(!imageView15.isSelected());
                if (imageView15.isSelected()) {
                    imageView15.setColorFilter(getResources().getColor(R.color.black));
                } else {
                    imageView15.setColorFilter(getResources().getColor(R.color.white));

                }
                break;
            case R.id.s16:
                imageView16.setSelected(!imageView16.isSelected());
                if (imageView16.isSelected()) {
                    imageView16.setColorFilter(getResources().getColor(R.color.black));
                } else {
                    imageView16.setColorFilter(getResources().getColor(R.color.white));

                }
                break;
            case R.id.s17:
                imageView17.setSelected(!imageView17.isSelected());
                if (imageView17.isSelected()) {
                    imageView17.setColorFilter(getResources().getColor(R.color.black));
                } else {
                    imageView17.setColorFilter(getResources().getColor(R.color.white));

                }
                break;
            case R.id.s18:
                imageView18.setSelected(!imageView18.isSelected());
                if (imageView18.isSelected()) {
                    imageView18.setColorFilter(getResources().getColor(R.color.black));
                } else {
                    imageView18.setColorFilter(getResources().getColor(R.color.white));

                }
                break;
            case R.id.s19:
                imageView19.setSelected(!imageView19.isSelected());
                if (imageView19.isSelected()) {
                    imageView19.setColorFilter(getResources().getColor(R.color.black));
                } else {
                    imageView19.setColorFilter(getResources().getColor(R.color.white));

                }

                break;
            case R.id.s20:
                imageView20.setSelected(!imageView20.isSelected());
                if (imageView20.isSelected()) {
                    imageView20.setColorFilter(getResources().getColor(R.color.black));
                } else {
                    imageView20.setColorFilter(getResources().getColor(R.color.white));

                }

                break;
            case R.id.s21:
                imageView21.setSelected(!imageView21.isSelected());
                if (imageView21.isSelected()) {
                    imageView21.setColorFilter(getResources().getColor(R.color.black));
                } else {
                    imageView21.setColorFilter(getResources().getColor(R.color.white));

                }
                break;
            case R.id.s22:
                imageView22.setSelected(!imageView22.isSelected());
                if (imageView22.isSelected()) {
                    imageView22.setColorFilter(getResources().getColor(R.color.black));
                } else {
                    imageView22.setColorFilter(getResources().getColor(R.color.white));

                }
                break;
            case R.id.s23:
                imageView23.setSelected(!imageView23.isSelected());
                if (imageView23.isSelected()) {
                    imageView23.setColorFilter(getResources().getColor(R.color.black));
                } else {
                    imageView23.setColorFilter(getResources().getColor(R.color.white));

                }
                break;
            case R.id.s24:
                imageView24.setSelected(!imageView24.isSelected());
                if (imageView24.isSelected()) {
                    imageView24.setColorFilter(getResources().getColor(R.color.black));
                } else {
                    imageView24.setColorFilter(getResources().getColor(R.color.white));

                }
                break;
            case R.id.s25:
                imageView25.setSelected(!imageView25.isSelected());
                if (imageView25.isSelected()) {
                    imageView25.setColorFilter(getResources().getColor(R.color.black));
                } else {
                    imageView25.setColorFilter(getResources().getColor(R.color.white));

                }
                break;
            case R.id.s26:
                imageView26.setSelected(!imageView26.isSelected());
                if (imageView26.isSelected()) {
                    imageView26.setColorFilter(getResources().getColor(R.color.black));
                } else {
                    imageView26.setColorFilter(getResources().getColor(R.color.white));

                }
                break;
            case R.id.s27:
                imageView27.setSelected(!imageView27.isSelected());
                if (imageView27.isSelected()) {
                    imageView27.setColorFilter(getResources().getColor(R.color.black));
                } else {
                    imageView27.setColorFilter(getResources().getColor(R.color.white));

                }
                break;
            case R.id.s28:
                imageView28.setSelected(!imageView28.isSelected());
                if (imageView28.isSelected()) {
                    imageView28.setColorFilter(getResources().getColor(R.color.black));
                } else {
                    imageView28.setColorFilter(getResources().getColor(R.color.white));

                }
                break;
            case R.id.s29:
                imageView29.setSelected(!imageView29.isSelected());
                if (imageView29.isSelected()) {
                    imageView29.setColorFilter(getResources().getColor(R.color.black));
                } else {
                    imageView29.setColorFilter(getResources().getColor(R.color.white));

                }

                break;
            case R.id.s30:
                imageView30.setSelected(!imageView30.isSelected());
                if (imageView30.isSelected()) {
                    imageView30.setColorFilter(getResources().getColor(R.color.black));
                } else {
                    imageView30.setColorFilter(getResources().getColor(R.color.white));

                }

                break;

            case R.id.s31:
                imageView31.setSelected(!imageView31.isSelected());
                if (imageView31.isSelected()) {
                    imageView31.setColorFilter(getResources().getColor(R.color.black));
                } else {
                    imageView31.setColorFilter(getResources().getColor(R.color.white));

                }
                break;
            case R.id.s32:
                imageView32.setSelected(!imageView32.isSelected());
                if (imageView32.isSelected()) {
                    imageView32.setColorFilter(getResources().getColor(R.color.black));
                } else {
                    imageView32.setColorFilter(getResources().getColor(R.color.white));

                }
                break;
            case R.id.s33:
                imageView33.setSelected(!imageView33.isSelected());
                if (imageView33.isSelected()) {
                    imageView33.setColorFilter(getResources().getColor(R.color.black));
                } else {
                    imageView33.setColorFilter(getResources().getColor(R.color.white));

                }
                break;
            case R.id.s34:
                imageView34.setSelected(!imageView34.isSelected());
                if (imageView34.isSelected()) {
                    imageView34.setColorFilter(getResources().getColor(R.color.black));
                } else {
                    imageView34.setColorFilter(getResources().getColor(R.color.white));

                }
                break;
            case R.id.s35:
                imageView35.setSelected(!imageView35.isSelected());
                if (imageView35.isSelected()) {
                    imageView35.setColorFilter(getResources().getColor(R.color.black));
                } else {
                    imageView35.setColorFilter(getResources().getColor(R.color.white));

                }
                break;
            case R.id.s36:
                imageView36.setSelected(!imageView36.isSelected());
                if (imageView36.isSelected()) {
                    imageView36.setColorFilter(getResources().getColor(R.color.black));
                } else {
                    imageView36.setColorFilter(getResources().getColor(R.color.white));

                }
                break;
            case R.id.s37:
                imageView37.setSelected(!imageView37.isSelected());
                if (imageView37.isSelected()) {
                    imageView37.setColorFilter(getResources().getColor(R.color.black));
                } else {
                    imageView37.setColorFilter(getResources().getColor(R.color.white));

                }
                break;
            case R.id.s38:
                imageView38.setSelected(!imageView38.isSelected());
                if (imageView38.isSelected()) {
                    imageView38.setColorFilter(getResources().getColor(R.color.black));
                } else {
                    imageView38.setColorFilter(getResources().getColor(R.color.white));

                }
                break;
            case R.id.s39:
                imageView39.setSelected(!imageView39.isSelected());
                if (imageView39.isSelected()) {
                    imageView39.setColorFilter(getResources().getColor(R.color.black));
                } else {
                    imageView39.setColorFilter(getResources().getColor(R.color.white));

                }

                break;
            case R.id.s40:
                imageView40.setSelected(!imageView40.isSelected());
                if (imageView40.isSelected()) {
                    imageView40.setColorFilter(getResources().getColor(R.color.black));
                } else {
                    imageView40.setColorFilter(getResources().getColor(R.color.white));

                }

                break;

            case R.id.s41:
                imageView41.setSelected(!imageView41.isSelected());
                if (imageView41.isSelected()) {
                    imageView41.setColorFilter(getResources().getColor(R.color.black));
                } else {
                    imageView41.setColorFilter(getResources().getColor(R.color.white));

                }
                break;
            case R.id.s42:
                imageView42.setSelected(!imageView42.isSelected());
                if (imageView42.isSelected()) {
                    imageView42.setColorFilter(getResources().getColor(R.color.black));
                } else {
                    imageView42.setColorFilter(getResources().getColor(R.color.white));

                }
                break;
            case R.id.s43:
                imageView43.setSelected(!imageView43.isSelected());
                if (imageView43.isSelected()) {
                    imageView43.setColorFilter(getResources().getColor(R.color.black));
                } else {
                    imageView43.setColorFilter(getResources().getColor(R.color.white));

                }
                break;
            case R.id.s44:
                imageView44.setSelected(!imageView44.isSelected());
                if (imageView44.isSelected()) {
                    imageView44.setColorFilter(getResources().getColor(R.color.black));
                } else {
                    imageView44.setColorFilter(getResources().getColor(R.color.white));

                }
                break;
            case R.id.s45:
                imageView45.setSelected(!imageView45.isSelected());
                if (imageView45.isSelected()) {
                    imageView45.setColorFilter(getResources().getColor(R.color.black));
                } else {
                    imageView45.setColorFilter(getResources().getColor(R.color.white));

                }
                break;
            case R.id.s46:
                imageView46.setSelected(!imageView46.isSelected());
                if (imageView46.isSelected()) {
                    imageView46.setColorFilter(getResources().getColor(R.color.black));
                } else {
                    imageView46.setColorFilter(getResources().getColor(R.color.white));

                }
                break;
            case R.id.s47:
                imageView47.setSelected(!imageView47.isSelected());
                if (imageView47.isSelected()) {
                    imageView47.setColorFilter(getResources().getColor(R.color.black));
                } else {
                    imageView47.setColorFilter(getResources().getColor(R.color.white));

                }
                break;
            case R.id.s48:
                imageView48.setSelected(!imageView48.isSelected());
                if (imageView48.isSelected()) {
                    imageView48.setColorFilter(getResources().getColor(R.color.black));
                } else {
                    imageView48.setColorFilter(getResources().getColor(R.color.white));

                }
                break;
            case R.id.s49:
                imageView49.setSelected(!imageView49.isSelected());
                if (imageView49.isSelected()) {
                    imageView49.setColorFilter(getResources().getColor(R.color.black));
                } else {
                    imageView49.setColorFilter(getResources().getColor(R.color.white));

                }

                break;
            case R.id.s50:
                imageView50.setSelected(!imageView50.isSelected());
                if (imageView50.isSelected()) {
                    imageView50.setColorFilter(getResources().getColor(R.color.black));
                } else {
                    imageView50.setColorFilter(getResources().getColor(R.color.white));

                }

                break;

            case R.id.s51:
                imageView51.setSelected(!imageView51.isSelected());
                if (imageView51.isSelected()) {
                    imageView51.setColorFilter(getResources().getColor(R.color.black));
                } else {
                    imageView51.setColorFilter(getResources().getColor(R.color.white));

                }
                break;
            case R.id.s52:
                imageView52.setSelected(!imageView52.isSelected());
                if (imageView52.isSelected()) {
                    imageView52.setColorFilter(getResources().getColor(R.color.black));
                } else {
                    imageView52.setColorFilter(getResources().getColor(R.color.white));

                }
                break;
            case R.id.s53:
                imageView53.setSelected(!imageView53.isSelected());
                if (imageView53.isSelected()) {
                    imageView53.setColorFilter(getResources().getColor(R.color.black));
                } else {
                    imageView53.setColorFilter(getResources().getColor(R.color.white));

                }
                break;
            case R.id.s54:
                imageView54.setSelected(!imageView54.isSelected());
                if (imageView54.isSelected()) {
                    imageView54.setColorFilter(getResources().getColor(R.color.black));
                } else {
                    imageView54.setColorFilter(getResources().getColor(R.color.white));

                }
                break;
            case R.id.s55:
                imageView55.setSelected(!imageView55.isSelected());
                if (imageView55.isSelected()) {
                    imageView55.setColorFilter(getResources().getColor(R.color.black));
                } else {
                    imageView55.setColorFilter(getResources().getColor(R.color.white));

                }
                break;
            case R.id.s56:
                imageView56.setSelected(!imageView56.isSelected());
                if (imageView56.isSelected()) {
                    imageView56.setColorFilter(getResources().getColor(R.color.black));
                } else {
                    imageView56.setColorFilter(getResources().getColor(R.color.white));

                }
                break;
            case R.id.s57:
                imageView57.setSelected(!imageView57.isSelected());
                if (imageView57.isSelected()) {
                    imageView57.setColorFilter(getResources().getColor(R.color.black));
                } else {
                    imageView57.setColorFilter(getResources().getColor(R.color.white));

                }
                break;
            case R.id.s58:
                imageView58.setSelected(!imageView58.isSelected());
                if (imageView58.isSelected()) {
                    imageView58.setColorFilter(getResources().getColor(R.color.black));
                } else {
                    imageView58.setColorFilter(getResources().getColor(R.color.white));

                }
                break;
            case R.id.s59:
                imageView59.setSelected(!imageView59.isSelected());
                if (imageView59.isSelected()) {
                    imageView59.setColorFilter(getResources().getColor(R.color.black));
                } else {
                    imageView59.setColorFilter(getResources().getColor(R.color.white));

                }

                break;
            case R.id.s60:
                imageView60.setSelected(!imageView60.isSelected());
                if (imageView60.isSelected()) {
                    imageView60.setColorFilter(getResources().getColor(R.color.black));
                } else {
                    imageView60.setColorFilter(getResources().getColor(R.color.white));

                }

                break;

            case R.id.s61:
                imageView61.setSelected(!imageView61.isSelected());
                if (imageView61.isSelected()) {
                    imageView61.setColorFilter(getResources().getColor(R.color.black));
                } else {
                    imageView61.setColorFilter(getResources().getColor(R.color.white));

                }
                break;
            case R.id.s62:
                imageView62.setSelected(!imageView62.isSelected());
                if (imageView62.isSelected()) {
                    imageView62.setColorFilter(getResources().getColor(R.color.black));
                } else {
                    imageView62.setColorFilter(getResources().getColor(R.color.white));

                }
                break;
            case R.id.s63:
                imageView63.setSelected(!imageView63.isSelected());
                if (imageView63.isSelected()) {
                    imageView63.setColorFilter(getResources().getColor(R.color.black));
                } else {
                    imageView63.setColorFilter(getResources().getColor(R.color.white));

                }
                break;
            case R.id.s64:
                imageView64.setSelected(!imageView64.isSelected());
                if (imageView64.isSelected()) {
                    imageView64.setColorFilter(getResources().getColor(R.color.black));
                } else {
                    imageView64.setColorFilter(getResources().getColor(R.color.white));

                }
                break;
            case R.id.s65:
                imageView65.setSelected(!imageView65.isSelected());
                if (imageView65.isSelected()) {
                    imageView65.setColorFilter(getResources().getColor(R.color.black));
                } else {
                    imageView65.setColorFilter(getResources().getColor(R.color.white));

                }
                break;
            case R.id.s66:
                imageView66.setSelected(!imageView66.isSelected());
                if (imageView66.isSelected()) {
                    imageView66.setColorFilter(getResources().getColor(R.color.black));
                } else {
                    imageView66.setColorFilter(getResources().getColor(R.color.white));

                }
                break;
            case R.id.s67:
                imageView67.setSelected(!imageView67.isSelected());
                if (imageView67.isSelected()) {
                    imageView67.setColorFilter(getResources().getColor(R.color.black));
                } else {
                    imageView67.setColorFilter(getResources().getColor(R.color.white));

                }
                break;
            case R.id.s68:
                imageView68.setSelected(!imageView68.isSelected());
                if (imageView68.isSelected()) {
                    imageView68.setColorFilter(getResources().getColor(R.color.black));
                } else {
                    imageView68.setColorFilter(getResources().getColor(R.color.white));

                }
                break;
            case R.id.s69:
                imageView69.setSelected(!imageView69.isSelected());
                if (imageView69.isSelected()) {
                    imageView69.setColorFilter(getResources().getColor(R.color.black));
                } else {
                    imageView69.setColorFilter(getResources().getColor(R.color.white));

                }

                break;
            case R.id.s70:
                imageView70.setSelected(!imageView70.isSelected());
                if (imageView70.isSelected()) {
                    imageView70.setColorFilter(getResources().getColor(R.color.black));
                } else {
                    imageView70.setColorFilter(getResources().getColor(R.color.white));

                }

                break;

        }
    }
}